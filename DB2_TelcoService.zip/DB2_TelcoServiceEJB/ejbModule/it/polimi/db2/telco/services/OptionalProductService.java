package it.polimi.db2.telco.services;

import java.util.List;
import java.util.Random;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import it.polimi.db2.telco.entities.*;

@Stateless
public class OptionalProductService {
	@PersistenceContext(unitName="DB2_TelcoServiceEJB")
	private EntityManager em;
	
	public OptionalProductService() {}
	
	public List<OptionalProduct> findAllProducts(){
		return em.createNamedQuery("OptionalProduct.findAll", OptionalProduct.class).getResultList();
	}
	
	public OptionalProduct findProductsById(int productId){
		OptionalProduct product = em.find(OptionalProduct.class, productId);
		return product;
	}
	
	public void createProduct(String name, float monthlyFee) {
		Random rand = new Random();
		int n = rand.nextInt(1000);
		OptionalProduct product=new OptionalProduct(n, name, monthlyFee);
		em.persist(product);
	}
}
