
package it.polimi.db2.telco.entities;

public enum ServiceType {
	fixed_phone,
	mobile_phone,
	fixed_internet,
	mobile_internet;
}
